---
title: "The UNCOVER Survey: A first-look HST+JWST catalog of 50,000 galaxies near Abell 2744 and beyond"
date: 2023-01-01
publishDate: 2023-01-17T21:01:22.108276Z
authors: ["John R. Weaver", "Sam E. Cutler", "Richard Pan", "Katherine E. Whitaker", "Ivo Labbe", "Sedona H. Price", "Rachel Bezanson", "Gabriel Brammer", "Danilo Marchesini", "Joel Leja", "Bingjie Wang", "Lukas J. Furtak", "Adi Zitrin", "Hakim Atek", "Dan Coe", "Pratika Dayal", "Pieter van Dokkum", "Robert Feldmann", "Natascha Forster Schreiber", "Marijn Franx", "Seiji Fujimoto", "Yoshinobu Fudamoto", "Karl Glazebrook", "Anna de Graaff", "Jenny E. Greene", "Stephanie Juneau", "Susan Kassin", "Mariska Kriek", "Gourav Khullar", "Michael Maseda", "Lamiya A. Mowla", "Adam Muzzin", "Themiya Nanayakkara", "Erica J. Nelson", "Pascal A. Oesch", "Camilla Pacifici", "Casey Papovich", "David Setton", "Alice E. Shapley", "Renske Smit", "Mauro Stefanon", "Edward N. Taylor", "Andrea Weibel", "Christina C. Williams"]
publication_types: ["2"]
abstract: ""
featured: false
publication: "*arXiv e-prints*"
tags: ["Astrophysics - Astrophysics of Galaxies"]
---

