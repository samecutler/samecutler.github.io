---
# Documentation: https://wowchemy.com/docs/managing-content/

title: 'Clumpy Relics: The First Spectroscopic Confirmation of Globular Clusters at
  z 3'
subtitle: ''
summary: ''
authors:
- Sam Edward Cutler
- Katherine E. Whitaker
- Rachel Bezanson
- Pratika Dayal
- Yoshinobu Fudamoto
- Seiji Fujimoto
- Gourav Khullar
- Vasily Kokorev
- Ivo Labbe
- Joel Leja
- Danilo Marchesini
- Michael Maseda
- Tim Blake Miller
- Themiya Nanayakkara
- Erica Nelson
- Richard Pan
- Sedona H. Price
- Francesca Rizzo
- David Setton
- Katherine Suess
- Bingjie Wang
- John R. Weaver
- Christina Williams
- Adi Zitrin
tags: []
categories: []
date: '2024-03-01'
lastmod: 2024-05-29T10:40:41-04:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2024-05-29T14:40:41.334742Z'
publication_types:
- '0'
abstract: ''
publication: ''
---
